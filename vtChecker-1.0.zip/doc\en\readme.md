# VirusTotal Checker

* Author: Komil Hamzayev <hamzayevkomil52@gmail.com>
* Source code: [GitHub Repository](https://github.com/komilblindev/vtChecker)
* NVDA compatibility: 2024.1.0 and beyond

This add-on allows you to easily check files, URLs, or Hashes using the VirusTotal API.

## Setup
1. Register for a free account at [VirusTotal](https://www.virustotal.com/).
2. Go to your Profile -> API Key and copy your key.
3. Open NVDA Settings -> VirusTotal, paste your API key, and configure preferences (auto-upload, beeps, etc.).

## Usage and Hotkeys
By default, no hotkeys are assigned. You must assign them manually:
1. Go to **NVDA Menu -> Preferences -> Input Gestures**.
2. Expand the **VirusTotal** category.
3. Assign shortcuts to the following commands:
   * **Check focused file:** Checks the currently selected file in Windows Explorer.
   * **Manual check dialog:** Opens a dialog to manually type or paste a URL, IP, or SHA-256 hash.

### Checking a file
When you press the hotkey on a file:
* **Single press:** NVDA announces a short summary (e.g. 0/91) and the full detailed report with the VT link is copied to your clipboard.
* **Double press:** Opens a browseable message containing the complete detailed report of all antivirus engines.

If a file is completely new to VirusTotal, the add-on can automatically upload it (if enabled in settings), wait for the queue in the background, and notify you as soon as the results are ready.


### API Limits
Note: The standard free VirusTotal API allows up to 4 requests per minute and 500 requests per day. You can check your current limit usage in the Add-on Settings.
